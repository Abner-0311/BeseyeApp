//
//  BeseyeStreamer.h
//  BeseyeStreamer
//
//  Created by Abner on 2013/12/10.
//  Copyright (c) 2013年 BesEye. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BeseyeStreamer : NSObject

@end
